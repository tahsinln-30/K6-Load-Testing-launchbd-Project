# Reads the 4-digit LaunchBD login image. k6 posts JPEG to http://127.0.0.1:18786/
Add-Type -AssemblyName System.Drawing
$port = 18787
$prefix = "http://127.0.0.1:$port/"

$Train = @(
  @{ d='0'; v=@(0.000,0.333,0.438,0.333,0.000,0.312,0.600,0.267,0.100) },
  @{ d='0'; v=@(0.167,0.250,0.438,0.333,0.000,0.312,0.533,0.200,0.100) },
  @{ d='1'; v=@(0.375,0.875,0.000,0.000,0.875,0.000,0.000,0.600,0.400) },
  @{ d='1'; v=@(0.375,0.875,0.000,0.000,1.000,0.000,0.100,1.000,0.200) },
  @{ d='2'; v=@(0.333,0.250,0.438,0.067,0.200,0.100,0.333,0.400,0.400) },
  @{ d='2'; v=@(0.333,0.500,0.250,0.067,0.267,0.067,0.400,0.400,0.400) },
  @{ d='2'; v=@(0.250,0.500,0.250,0.067,0.333,0.067,0.400,0.400,0.400) },
  @{ d='2'; v=@(0.333,0.500,0.250,0.067,0.333,0.067,0.467,0.400,0.400) },
  @{ d='2'; v=@(0.333,0.250,0.438,0.067,0.133,0.100,0.267,0.400,0.400) },
  @{ d='3'; v=@(0.333,0.583,0.083,0.133,0.333,0.400,0.400,0.200,0.200) },
  @{ d='3'; v=@(0.333,0.333,0.333,0.133,0.467,0.400,0.333,0.200,0.400) },
  @{ d='3'; v=@(0.417,0.583,0.250,0.133,0.400,0.400,0.267,0.200,0.200) },
  @{ d='3'; v=@(0.500,0.250,0.667,0.250,0.417,0.417,0.500,0.133,0.333) },
  @{ d='4'; v=@(0.000,0.333,0.250,0.167,0.167,0.625,0.200,0.267,0.500) },
  @{ d='5'; v=@(0.500,0.500,0.333,0.250,0.250,0.750,0.200,0.200,0.333) },
  @{ d='5'; v=@(0.467,0.400,0.200,0.400,0.267,0.600,0.333,0.200,0.200) },
  @{ d='6'; v=@(0.333,0.250,0.312,0.583,0.250,0.375,0.533,0.267,0.500) },
  @{ d='6'; v=@(0.333,0.250,0.250,0.583,0.250,0.375,0.533,0.267,0.500) },
  @{ d='7'; v=@(0.500,0.500,0.583,0.100,0.067,0.267,0.000,0.333,0.333) },
  @{ d='7'; v=@(0.750,0.583,0.500,0.000,0.000,0.333,0.000,0.333,0.333) },
  @{ d='8'; v=@(0.333,0.167,0.375,0.417,0.500,0.438,0.533,0.200,0.450) },
  @{ d='8'; v=@(0.333,0.333,0.500,0.467,0.400,0.467,0.600,0.267,0.333) },
  @{ d='8'; v=@(0.333,0.333,0.375,0.467,0.333,0.300,0.667,0.267,0.300) },
  @{ d='8'; v=@(0.417,0.250,0.375,0.333,0.500,0.312,0.467,0.200,0.400) },
  @{ d='9'; v=@(0.500,0.333,0.500,0.500,0.250,0.583,0.133,0.200,0.400) },
  @{ d='9'; v=@(0.417,0.417,0.438,0.500,0.250,0.438,0.200,0.200,0.300) },
  @{ d='9'; v=@(0.500,0.250,0.583,0.417,0.250,0.750,0.333,0.200,0.400) }
)

function Get-DigitFeatures([System.Drawing.Bitmap]$bmp) {
  $w = $bmp.Width
  $h = $bmp.Height
  $cols = New-Object int[] $w
  for ($x = 0; $x -lt $w; $x++) {
    $n = 0
    for ($y = 0; $y -lt $h; $y++) { if ($bmp.GetPixel($x, $y).R -lt 100) { $n++ } }
    $cols[$x] = $n
  }
  $starts = New-Object System.Collections.Generic.List[int]
  $ends = New-Object System.Collections.Generic.List[int]
  $inside = $false
  $start = 0
  for ($x = 0; $x -lt $w; $x++) {
    $on = $cols[$x] -ge 1
    if ($on -and -not $inside) { $inside = $true; $start = $x }
    elseif ((-not $on) -and $inside) {
      $inside = $false
      if (($x - $start) -ge 2) { [void]$starts.Add($start); [void]$ends.Add($x - 1) }
    }
  }
  $out = New-Object System.Collections.Generic.List[object]
  for ($bi = 0; $bi -lt $starts.Count; $bi++) {
    $x0 = $starts[$bi]
    $x1 = $ends[$bi]
    $y0 = $h
    $y1 = 0
    for ($x = $x0; $x -le $x1; $x++) {
      for ($y = 0; $y -lt $h; $y++) {
        if ($bmp.GetPixel($x, $y).R -lt 100) {
          if ($y -lt $y0) { $y0 = $y }
          if ($y -gt $y1) { $y1 = $y }
        }
      }
    }
    $gw = [Math]::Max(1, $x1 - $x0 + 1)
    $gh = [Math]::Max(1, $y1 - $y0 + 1)
    $cell = New-Object 'double[]' 9
    for ($ry = 0; $ry -lt 3; $ry++) {
      for ($cx = 0; $cx -lt 3; $cx++) {
        $sx = $x0 + [int][Math]::Floor($cx * $gw / 3)
        $ex = $x0 + [int][Math]::Floor(($cx + 1) * $gw / 3) - 1
        $sy = $y0 + [int][Math]::Floor($ry * $gh / 3)
        $ey = $y0 + [int][Math]::Floor(($ry + 1) * $gh / 3) - 1
        if ($ex -lt $sx) { $ex = $sx }
        if ($ey -lt $sy) { $ey = $sy }
        $dark = 0
        $tot = 0
        for ($x = $sx; $x -le $ex; $x++) {
          for ($y = $sy; $y -le $ey; $y++) {
            $tot++
            if ($bmp.GetPixel($x, $y).R -lt 100) { $dark++ }
          }
        }
        $cell[$ry * 3 + $cx] = $(if ($tot -gt 0) { $dark / $tot } else { 0 })
      }
    }
    [void]$out.Add($cell)
  }
  return $out
}

function Classify([double[]]$cell) {
  $best = '?'
  $bestD = 1e9
  foreach ($t in $Train) {
    $d = 0.0
    for ($i = 0; $i -lt 9; $i++) {
      $diff = $cell[$i] - $t.v[$i]
      $d += $diff * $diff
    }
    if ($d -lt $bestD) { $bestD = $d; $best = $t.d }
  }
  return $best
}

function Solve-Bytes([byte[]]$bytes) {
  $tmp = [IO.Path]::Combine($env:TEMP, "k6-captcha-" + [Guid]::NewGuid().ToString("N") + ".jpg")
  [IO.File]::WriteAllBytes($tmp, $bytes)
  try {
    $bmp = [System.Drawing.Bitmap]::FromFile($tmp)
    try {
      $feats = Get-DigitFeatures $bmp
      $code = ''
      foreach ($f in $feats) { $code += Classify $f }
      return $code
    } finally { $bmp.Dispose() }
  } finally {
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
  }
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
try { $listener.Start() } catch { Write-Host "OCR already running on $prefix"; exit 0 }
Write-Host "Captcha OCR listening on $prefix"

while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $code = ''
  try {
    $ms = New-Object System.IO.MemoryStream
    $buf = New-Object byte[] 8192
    while (($n = $ctx.Request.InputStream.Read($buf, 0, $buf.Length)) -gt 0) { $ms.Write($buf, 0, $n) }
    $raw = $ms.ToArray()
    $ms.Dispose()
    $bytes = $raw
    if ($raw.Length -gt 50) {
      $asText = [Text.Encoding]::ASCII.GetString($raw).Trim()
      if ($asText -match '^[A-Za-z0-9+/=]+$') {
        try { $bytes = [Convert]::FromBase64String($asText) } catch { $bytes = $raw }
      }
      $code = Solve-Bytes $bytes
    }
    Write-Host ("ocr=[{0}] bytes={1}" -f $code, $bytes.Length)
  } catch {
    Write-Host ("ocr error: {0}" -f $_)
  }
  $out = [Text.Encoding]::ASCII.GetBytes([string]$code)
  $ctx.Response.StatusCode = 200
  $ctx.Response.ContentType = 'text/plain'
  $ctx.Response.ContentLength64 = $out.Length
  $ctx.Response.OutputStream.Write($out, 0, $out.Length)
  $ctx.Response.Close()
}
