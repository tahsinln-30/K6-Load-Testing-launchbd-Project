import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Counter } from 'k6/metrics';
import { SharedArray } from 'k6/data';

/**
 * Shyamoli staging — admin counter booking load test
 *
 * Flow:
 *   Home → Admin login → Search (Leaving From / Going To / Departing On)
 *   → View Seat → select seat → passenger + boarding/dropping → Confirm
 *
 * Users: admin-users.txt (one username per line). Password defaults to 123456.
 *
 *   k6 run admin-counter-loadtest.js
 *   k6 run -e VUS=20 -e DEPART_DATE=25/10/2026 admin-counter-loadtest.js
 *   k6 run -e VUS=1 -e ITERATIONS=1 admin-counter-loadtest.js
 */

const BASE_URL = __ENV.BASE_URL || 'https://staging.shyamoliparibahan-bd.com';
const DEPART_DATE = __ENV.DEPART_DATE || '25/10/2026';
const PASSWORD = __ENV.PASSWORD || '123456';
const VUS = Number(__ENV.VUS || 10);
const ITERATIONS = Number(__ENV.ITERATIONS || 1);
const MAX_COACH_TRIES = Number(__ENV.MAX_COACH_TRIES || 4);
const MAX_SEAT_TRIES = Number(__ENV.MAX_SEAT_TRIES || 4);
const STAGGER_SEC = Number(__ENV.STAGGER_SEC || 0.8);

const DISTRICTS = {
  Dhaka: '14',
  Bandarban: '2',
  Chittagong: '10',
  Sylhet: '63',
  "Cox's Bazar": '13',
  Rangamati: '56',
};

const ROUTES = [
  ['Dhaka', 'Bandarban'],
  ['Dhaka', 'Chittagong'],
  ['Dhaka', 'Sylhet'],
  ['Dhaka', "Cox's Bazar"],
  ['Dhaka', 'Rangamati'],
  ['Bandarban', 'Dhaka'],
  ['Chittagong', 'Dhaka'],
  ['Sylhet', 'Dhaka'],
  ["Cox's Bazar", 'Dhaka'],
  ['Rangamati', 'Dhaka'],
];

const users = new SharedArray('admin-users', function () {
  const raw = open('./admin-users.txt');
  const rows = [];
  const lines = raw.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line || line.charAt(0) === '#') continue;
    const comma = line.indexOf(',');
    if (comma === -1) {
      rows.push({ username: line, password: PASSWORD });
    } else {
      const username = line.slice(0, comma).trim();
      const password = line.slice(comma + 1).trim() || PASSWORD;
      if (username.toLowerCase() === 'username') continue;
      rows.push({ username: username, password: password });
    }
  }
  if (!rows.length) {
    rows.push({ username: 'busbd', password: PASSWORD });
  }
  return rows;
});

export const options = {
  scenarios: {
    counter_booking: {
      executor: 'per-vu-iterations',
      vus: VUS,
      iterations: ITERATIONS,
      maxDuration: __ENV.MAX_DURATION || '15m',
      gracefulStop: '30s',
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.5'],
    login_success: ['count>0'],
  },
};

const loginSuccess = new Counter('login_success');
const loginFail = new Counter('login_fail');
const searchSuccess = new Counter('search_success');
const searchFail = new Counter('search_fail');
const seatViewSuccess = new Counter('seatview_success');
const seatViewFail = new Counter('seatview_fail');
const bookSuccess = new Counter('book_success');
const bookFail = new Counter('book_fail');

http.setResponseCallback(http.expectedStatuses(200, 302, 400, 409, 500, 502, 503, 504));

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

function formBody(obj) {
  const parts = [];
  const keys = Object.keys(obj);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    const value = obj[key] == null ? '' : obj[key];
    parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
  }
  return parts.join('&');
}

function htmlHeaders(referer) {
  return {
    'Content-Type': 'application/x-www-form-urlencoded',
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'User-Agent': UA,
    Referer: referer || BASE_URL + '/',
  };
}

function ajaxHeaders(referer) {
  return {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    Accept: 'application/json, text/javascript, */*; q=0.01',
    'X-Requested-With': 'XMLHttpRequest',
    'User-Agent': UA,
    Referer: referer || BASE_URL + '/en_US/admin/dashboard',
  };
}

function isTransient(res) {
  return !res || res.status === 0 || res.status === 502 || res.status === 503 || res.status === 504;
}

function requestWithRetry(method, url, body, params, maxAttempts) {
  const attempts = maxAttempts || 3;
  let res = null;
  const opts = Object.assign({ timeout: '60s' }, params || {});
  for (let attempt = 1; attempt <= attempts; attempt++) {
    if (method === 'GET') res = http.get(url, opts);
    else res = http.post(url, body, opts);
    if (!isTransient(res)) return res;
    if (attempt < attempts) sleep(1.2 * attempt);
  }
  return res;
}

function safeJson(res) {
  if (!res || !res.body) return null;
  try {
    return res.json();
  } catch (e) {
    return null;
  }
}

function asList(value) {
  if (!value) return [];
  if (Array.isArray(value)) {
    const out = [];
    for (let i = 0; i < value.length; i++) {
      if (value[i]) out.push(value[i]);
    }
    return out;
  }
  const out = [];
  const keys = Object.keys(value);
  for (let i = 0; i < keys.length; i++) {
    if (value[keys[i]]) out.push(value[keys[i]]);
  }
  return out;
}

function extractLoginCsrf(html) {
  const match = String(html).match(/name="csrf"\s+value="([^"]+)"/i);
  return match ? match[1] : '';
}

function extractDashboardCsrf(html) {
  const match = String(html).match(/csrfToken\s*=\s*"([a-f0-9]+)"/i);
  return match ? match[1] : '';
}

function routeForVu(vu, iter) {
  const index = (vu - 1 + (iter - 1)) % ROUTES.length;
  const pair = ROUTES[index];
  return {
    fromName: pair[0],
    toName: pair[1],
    fromId: DISTRICTS[pair[0]],
    toId: DISTRICTS[pair[1]],
  };
}

function userForVu(vu) {
  return users[(vu - 1) % users.length];
}

function mobileFor(vu, iter) {
  return String(17000000000 + ((vu - 1) * 50 + (iter - 1)) % 100000000);
}

function isOpenCoach(coach) {
  if (!coach || !coach.coachconfig_sku) return false;
  const status = coach.status == null ? '' : String(coach.status).toLowerCase();
  const configStatus = coach.coachconfig_status == null ? '' : String(coach.coachconfig_status).toLowerCase();
  if (!status && configStatus === 'open') return true;
  return status === 'open';
}

function fareFor(allFares, fromId, toId, seatTypeId) {
  const rows = asList(allFares);
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (
      String(row.from_district_id) === String(fromId) &&
      String(row.to_district_id) === String(toId) &&
      String(row.seat_type_id) === String(seatTypeId)
    ) {
      return String(row.fare);
    }
  }
  return '';
}

function pointTitle(name, time) {
  if (!time) return name;
  return name + ' ( ' + time + ' ) ';
}

function pickPoint(points, districtKey, districtId) {
  const rows = asList(points);
  rows.sort(function (a, b) {
    return (Number(a.config_details_sort) || 0) - (Number(b.config_details_sort) || 0);
  });
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][districtKey]) === String(districtId)) return rows[i];
  }
  return rows.length ? rows[0] : null;
}

function takenIds(map) {
  const ids = {};
  if (!map || Array.isArray(map)) return ids;
  const keys = Object.keys(map);
  for (let i = 0; i < keys.length; i++) ids[String(keys[i])] = true;
  return ids;
}

function availableSeats(seatData, fromId, toId) {
  const details = asList(seatData.seatstructure_details);
  const sold = takenIds(seatData.coach_seatstatus);
  const held = takenIds(seatData.temporary_booked);
  const vip = asList(seatData.vip_seatquota);
  const blocked = {};
  for (let i = 0; i < vip.length; i++) {
    if (vip[i]) blocked[String(vip[i])] = true;
  }
  const seats = [];
  for (let i = 0; i < details.length; i++) {
    const seat = details[i];
    if (!seat || !seat.seat_structure_details_id || !seat.seat_no) continue;
    const id = String(seat.seat_structure_details_id);
    if (sold[id] || held[id] || blocked[id]) continue;
    const fare = fareFor(seatData.coach_allfares, fromId, toId, seat.seat_type_id);
    if (!fare || Number(fare) <= 0) continue;
    seats.push({
      id: id,
      seatNo: String(seat.seat_no),
      seatTypeId: String(seat.seat_type_id),
      fare: fare,
    });
  }
  return seats;
}

function login(user) {
  const home = requestWithRetry('GET', BASE_URL + '/', null, {
    headers: { 'User-Agent': UA, Accept: 'text/html' },
    tags: { name: '01_Home' },
  }, 2);

  const loginPage = requestWithRetry('GET', BASE_URL + '/en_US/login', null, {
    headers: { 'User-Agent': UA, Accept: 'text/html', Referer: BASE_URL + '/' },
    tags: { name: '02_LoginPage' },
  }, 2);

  const csrf = loginPage && extractLoginCsrf(loginPage.body);
  if (!csrf) return null;

  const body = formBody({
    form_key: '',
    csrf: csrf,
    username: user.username,
    password: user.password,
    'g-recaptcha-response': '',
    google_captcha_site_key: '6Ld8ISssAAAAANLAtGnPM9zE8WuJHTiyYdJaANAi',
    macAddress: '',
    device_token: 'k6-' + user.username,
    LoginWidgetSubmitButton: 'Login',
  });

  const res = requestWithRetry('POST', BASE_URL + '/en_US/login', body, {
    headers: htmlHeaders(BASE_URL + '/en_US/login'),
    redirects: 5,
    tags: { name: '03_Login' },
  }, 2);

  const dashboardCsrf = res && extractDashboardCsrf(res.body);
  const ok = !!(res && res.status === 200 && dashboardCsrf);
  check(res, { 'login reaches dashboard': function () { return ok; } });
  if (!ok) return null;
  return { csrf: dashboardCsrf };
}

function searchCoaches(session, route) {
  const body = formBody({
    csrfToken: session.csrf,
    searchmenu_leavingform: route.fromId,
    searchmenu_goingto: route.toId,
    searchmenu_coachno: '',
    searchmenu_departingon: DEPART_DATE,
    searchmenu_departingtime: '',
    searchmenu_search_type: '0',
    searchmenu_submitbutton: 'Search',
    seatbooking_token: '',
  });

  const res = requestWithRetry(
    'POST',
    BASE_URL + '/en_US/admin/counter/for/seatbookingsearch',
    body,
    {
      headers: ajaxHeaders(BASE_URL + '/en_US/admin/dashboard'),
      tags: { name: '04_Search' },
    },
    3
  );

  const data = safeJson(res);
  const coaches = data && Array.isArray(data.contents) ? data.contents.filter(isOpenCoach) : [];
  const ok = !!(res && res.status === 200 && coaches.length);
  check(res, { 'search returns coaches': function () { return ok; } });
  return ok ? coaches : null;
}

function viewSeats(session, coach, route) {
  const body = formBody({
    schedule: coach.departure_time || '',
    cc_sku: coach.coachconfig_sku,
    journey_date: DEPART_DATE,
    to_district: route.toId,
    from_district: route.fromId,
    selectedBordingPoint: '',
    selectedDroppingPoint: '',
    csrfToken: session.csrf,
  });

  const res = requestWithRetry(
    'POST',
    BASE_URL + '/en_US/ajax/counterseatbooking/coach/seatlist',
    body,
    {
      headers: ajaxHeaders(BASE_URL + '/en_US/admin/dashboard'),
      tags: { name: '05_ViewSeat' },
    },
    2
  );

  const data = safeJson(res);
  const ok = !!(res && res.status === 200 && data && data.message === 'success');
  check(res, { 'view seat': function () { return ok; } });
  return ok ? data : null;
}

function randomTicket() {
  const res = requestWithRetry(
    'POST',
    BASE_URL + '/en_US/ajax/issue/ticket/randomticketnumber',
    'random_number=1',
    {
      headers: ajaxHeaders(BASE_URL + '/en_US/admin/dashboard'),
      tags: { name: '06_TicketNo' },
    },
    2
  );
  const ticket = res && res.status === 200 ? String(res.body || '').trim() : '';
  if (!ticket || ticket.charAt(0) === '<' || ticket.charAt(0) === '{') return '';
  return ticket;
}

function confirmBooking(session, coach, route, seat, boarding, dropping, passenger) {
  const body = formBody({
    sashroyToken: '',
    sashroyTransactionID: '',
    sashroyTicketAttr: '',
    eMail: '',
    goods_weight: '',
    goods_discount: '',
    goods_fare: '0',
    couponTitle: '',
    couponCodeToken: '',
    iscounterquotaallowed: '',
    complementary_seats: '',
    currentallowedquota: '',
    quota_status: 'false',
    seat_count: '1',
    seats: seat.id,
    seats_title: seat.seatNo,
    seats_fare: seat.fare,
    discount_fare: '0',
    amount: seat.fare,
    bording_point: boarding.id,
    bording_point_title: boarding.title,
    droppingpoint: dropping.id,
    droppingpoint_title: dropping.title,
    name: passenger.name,
    buyer_address: '',
    buyer_passport: '',
    additional_passenger_name: '',
    additional_passenger_passport: '',
    gender: 'Male',
    age: '',
    reg: '',
    mobile_prefix: '+88',
    mobile: passenger.mobile,
    bags_pics: '',
    bags_weight: '',
    counter_payment_method_id: 'cash',
    counter_payment_method_title: 'Cash',
    nationality_id: 'bangladesh',
    nationality_title: 'Bangladesh',
    buyer_visa_no: '',
    buyer_visa_exp_date: '',
    journey_date: DEPART_DATE,
    journey_time: coach.departure_time || '',
    from_district: boarding.districtId || route.fromId,
    to_district: dropping.districtId || route.toId,
    tickets_flag: '',
    tickets_flag_id: '',
    tickets_no: passenger.ticketNo,
    booking_type: 'seat_issue',
    cc_sku: coach.coachconfig_sku,
    booking_expire_date: '',
    booking_expire_time: '',
    advancePaid: '0',
    applied_variable_discount_amount: '0',
    csrfToken: session.csrf,
  });

  const res = requestWithRetry(
    'POST',
    BASE_URL + '/en_US/ajax/counter/seatbooking/ticket/purchase',
    body,
    {
      headers: ajaxHeaders(BASE_URL + '/en_US/admin/dashboard'),
      tags: { name: '07_Confirm' },
      timeout: '90s',
    },
    2
  );

  const data = safeJson(res);
  if (data && data.csrfToken) session.csrf = data.csrfToken;
  const ok = !!(res && res.status === 200 && data && data.message === 'success');
  check(res, { 'confirm booking': function () { return ok; } });
  return { ok: ok, data: data, status: res ? res.status : 0 };
}

export default function () {
  const vu = __VU;
  const iter = __ITER;
  const user = userForVu(vu);
  const route = routeForVu(vu, iter);

  sleep((vu - 1) * STAGGER_SEC + Math.random() * 0.4);

  let session;
  group('Login', function () {
    session = login(user);
  });
  if (!session) {
    loginFail.add(1);
    console.log('FAIL Login VU=' + vu + ' user=' + user.username);
    return;
  }
  loginSuccess.add(1);

  let coaches;
  group('Search', function () {
    coaches = searchCoaches(session, route);
  });
  if (!coaches) {
    searchFail.add(1);
    console.log('FAIL Search VU=' + vu + ' ' + route.fromName + ' -> ' + route.toName + ' date=' + DEPART_DATE);
    return;
  }
  searchSuccess.add(1);
  console.log(
    'OK Search VU=' + vu + ' user=' + user.username + ' ' + route.fromName + ' -> ' + route.toName + ' coaches=' + coaches.length
  );

  const start = (vu + iter) % coaches.length;
  const ordered = coaches.slice(start).concat(coaches.slice(0, start));
  const coachLimit = Math.min(MAX_COACH_TRIES, ordered.length);
  let booked = false;
  let lastReason = 'no_seat';

  for (let c = 0; c < coachLimit && !booked; c++) {
    const coach = ordered[c];
    sleep(0.2 + Math.random() * 0.4);

    let seatData;
    group('ViewSeat', function () {
      seatData = viewSeats(session, coach, route);
    });
    if (!seatData) {
      seatViewFail.add(1);
      lastReason = 'seatview_failed';
      continue;
    }
    seatViewSuccess.add(1);

    const boardingRow = pickPoint(seatData.bording_points, 'fromcounter_districtid', route.fromId);
    const droppingRow = pickPoint(seatData.dropping_points, 'tocounter_districtid', route.toId);
    if (!boardingRow || !droppingRow || !boardingRow.reporting_branch_id || !droppingRow.reporting_branch_id) {
      lastReason = 'no_boarding_dropping';
      continue;
    }

    const boarding = {
      id: String(boardingRow.reporting_branch_id),
      title: pointTitle(boardingRow.counter_name, boardingRow.reporting_time),
      districtId: String(boardingRow.fromcounter_districtid || route.fromId),
    };
    const dropping = {
      id: String(droppingRow.reporting_branch_id),
      title: pointTitle(droppingRow.counter_name, droppingRow.droping_time),
      districtId: String(droppingRow.tocounter_districtid || route.toId),
    };

    const seats = availableSeats(seatData, route.fromId, route.toId);
    if (!seats.length) {
      lastReason = 'no_free_seat';
      continue;
    }

    const seatStart = (vu + c) % seats.length;
    const seatOrder = seats.slice(seatStart).concat(seats.slice(0, seatStart));
    const seatLimit = Math.min(MAX_SEAT_TRIES, seatOrder.length);

    for (let s = 0; s < seatLimit && !booked; s++) {
      const seat = seatOrder[s];
      const ticketNo = randomTicket();
      if (!ticketNo) {
        lastReason = 'ticket_number_failed';
        continue;
      }

      const passenger = {
        name: 'Load ' + user.username + ' ' + vu,
        mobile: mobileFor(vu, iter),
        ticketNo: ticketNo,
      };

      let result;
      group('Confirm', function () {
        result = confirmBooking(session, coach, route, seat, boarding, dropping, passenger);
      });

      if (result.ok) {
        booked = true;
        bookSuccess.add(1);
        const ticketOut = (result.data && (result.data.ticket_no || result.data.ticketNo)) || ticketNo;
        console.log(
          'OK Confirm VU=' +
            vu +
            ' ' +
            route.fromName +
            ' -> ' +
            route.toName +
            ' coach=' +
            coach.coach_no +
            ' seat=' +
            seat.seatNo +
            ' fare=' +
            seat.fare +
            ' ticket=' +
            ticketOut
        );
        break;
      }

      lastReason =
        (result.data && (result.data.message_details || result.data.message)) ||
        'confirm_failed_' + result.status;
      console.log(
        'FAIL Confirm attempt VU=' + vu + ' coach=' + coach.coach_no + ' seat=' + seat.seatNo + ' reason=' + lastReason
      );
    }
  }

  if (!booked) {
    bookFail.add(1);
    console.log('FAIL Confirm VU=' + vu + ' ' + route.fromName + ' -> ' + route.toName + ' reason=' + lastReason);
  }

  sleep(0.3);
}

export function handleSummary(data) {
  const get = function (name) {
    return (data.metrics[name] && data.metrics[name].values && data.metrics[name].values.count) || 0;
  };

  const report =
    '\n============================================================\n' +
    'Shyamoli staging — admin counter booking\n' +
    'URL  : ' + BASE_URL + '\n' +
    'Date : ' + DEPART_DATE + '\n' +
    'VUs  : ' + VUS + '  iterations/VU : ' + ITERATIONS + '\n' +
    'Users: ' + users.length + '\n' +
    '============================================================\n' +
    'Login    success : ' + get('login_success') + '\n' +
    'Login    failed  : ' + get('login_fail') + '\n' +
    'Search   success : ' + get('search_success') + '\n' +
    'Search   failed  : ' + get('search_fail') + '\n' +
    'ViewSeat success : ' + get('seatview_success') + '\n' +
    'ViewSeat failed  : ' + get('seatview_fail') + '\n' +
    'Confirm  success : ' + get('book_success') + '\n' +
    'Confirm  failed  : ' + get('book_fail') + '\n' +
    '============================================================\n';

  return {
    stdout: report,
    'admin-counter-result.json': JSON.stringify(
      {
        login_success: get('login_success'),
        login_fail: get('login_fail'),
        search_success: get('search_success'),
        search_fail: get('search_fail'),
        seatview_success: get('seatview_success'),
        seatview_fail: get('seatview_fail'),
        book_success: get('book_success'),
        book_fail: get('book_fail'),
      },
      null,
      2
    ),
  };
}
